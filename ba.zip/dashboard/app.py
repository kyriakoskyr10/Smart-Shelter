import streamlit as st
import requests
import os

ORION_URL = os.getenv("ORION_URL", "http://orion:1026")
GRAFANA_PUBLIC_URL = os.getenv("GRAFANA_URL", "http://localhost:3000")
FIWARE_SERVICE = "smart_shelter"
FIWARE_SERVICEPATH = "/"

DASHBOARD_UID = "smart_shelter_v1"
ANIMAL_PANELS = {"Heart Rate": 2, "Activity": 3, "Body Temp": 4, "Sound": 5}
ROOM_PANELS = {"Temperature": 6, "Humidity": 7, "CO2": 8, "Ammonia": 9}

st.set_page_config(page_title="Smart Shelter", layout="wide", initial_sidebar_state="collapsed")

st.markdown("""
<style>
    div[data-testid="stButton"] button[kind="primary"] {
        min-height: 140px !important;
        background-color: #FFFFFF !important;
        border: 2px solid #8B4513 !important;
        border-radius: 15px;
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }
    
    div[data-testid="stButton"] button[kind="primary"] p {
        font-size: 30px !important;
        font-weight: 600 !important;
        color: #3E2723 !important;
        line-height: 1.2 !important;
    }
    
    div[data-testid="stButton"] button[kind="primary"] div {
        font-size: 30px !important;
    }

    div[data-testid="stButton"] button[kind="primary"]:hover {
        background-color: #F0EAD6 !important;
        border-color: #5D4037 !important;
        transform: scale(1.02);
    }
    
    div[data-testid="stButton"] button[kind="secondary"] {
        height: 50px !important;
        min-height: 50px !important;
        font-size: 16px !important;
        font-weight: 600 !important;
        background-color: #FFFFFF;
        border: 1px solid #CCC;
        border-radius: 8px;
        color: #333;
    }
    div[data-testid="stButton"] button[kind="secondary"] p {
        font-size: 16px !important;
    }
    div[data-testid="stButton"] button[kind="secondary"]:hover {
        border-color: #8B4513;
        color: #8B4513;
        background-color: #FAFAFA;
    }

    div[data-testid="metric-container"] {
        background-color: #FFFFFF;
        border: 1px solid #CCC;
        border-radius: 6px;
        padding: 5px;
    }
    .header-title { font-size: 28px; font-weight: 900; color: #3E2723; margin-top: 5px; }
</style>
""", unsafe_allow_html=True)

def get_headers():
    return {"Fiware-Service": FIWARE_SERVICE, "Fiware-ServicePath": FIWARE_SERVICEPATH}

def get_data(endpoint):
    try:
        r = requests.get(f"{ORION_URL}/v2/entities{endpoint}", headers=get_headers())
        return r.json() if r.status_code == 200 else []
    except:
        return []

if 'view' not in st.session_state: st.session_state.view = 'home'
if 'selected_id' not in st.session_state: st.session_state.selected_id = None

def navigate(view, animal_id=None):
    st.session_state.view = view
    st.session_state.selected_id = animal_id
    st.rerun()

def render_header():
    room = get_data("/Room:1?type=Room&options=keyValues")
    if isinstance(room, list): room = {} 
    
    c = st.columns([0.6, 3.0, 1.2, 1.2, 1.2, 1.2, 1.6])
    
    with c[0]: 
        if st.button("🏠", type="secondary", use_container_width=True): navigate('home')
    with c[1]: 
        st.markdown('<div class="header-title">Shelter Admin</div>', unsafe_allow_html=True)
    with c[2]: st.metric("Temp", f"{room.get('temperature', 0)}°C")
    with c[3]: st.metric("Hum", f"{room.get('humidity', 0)}%")
    with c[4]: st.metric("CO2", f"{room.get('co2', 0)}")
    with c[5]: st.metric("NH3", f"{room.get('ammonia', 0)}")
    with c[6]: 
        st.write("")
        if st.button("📉 Room History", type="secondary", help="View Room Graphs", use_container_width=True): 
            navigate('room')
    st.markdown("---")

def render_home():
    st.markdown("#### Occupants")
    animals = get_data("?type=Animal&options=keyValues&limit=100")
    if not animals: st.info("No animals found.")
    
    cols = st.columns(4)
    for i, a in enumerate(animals):
        aid = a.get("id", "Unknown")
        label = aid.split(":")[-1]
        with cols[i % 4]:
            if st.button(label, key=aid, type="primary", use_container_width=True): navigate('animal', aid)

def render_room():
    st.markdown("#### Room Environment History")
    g1, g2 = st.columns(2)
    with g1:
        st.caption("Temperature")
        st.components.v1.iframe(f"{GRAFANA_PUBLIC_URL}/d-solo/{DASHBOARD_UID}/smart-shelter-monitor?orgId=1&panelId={ROOM_PANELS['Temperature']}&refresh=5s&theme=light", height=300)
        st.caption("CO2")
        st.components.v1.iframe(f"{GRAFANA_PUBLIC_URL}/d-solo/{DASHBOARD_UID}/smart-shelter-monitor?orgId=1&panelId={ROOM_PANELS['CO2']}&refresh=5s&theme=light", height=300)
    with g2:
        st.caption("Humidity")
        st.components.v1.iframe(f"{GRAFANA_PUBLIC_URL}/d-solo/{DASHBOARD_UID}/smart-shelter-monitor?orgId=1&panelId={ROOM_PANELS['Humidity']}&refresh=5s&theme=light", height=300)
        st.caption("Ammonia")
        st.components.v1.iframe(f"{GRAFANA_PUBLIC_URL}/d-solo/{DASHBOARD_UID}/smart-shelter-monitor?orgId=1&panelId={ROOM_PANELS['Ammonia']}&refresh=5s&theme=light", height=300)

def render_animal():
    aid = st.session_state.selected_id
    st.markdown(f"#### Details: {aid}")
    
    data = get_data(f"/{aid}?type=Animal&options=keyValues")
    if isinstance(data, list): data = {}

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Heart Rate", f"{data.get('heartRate', 0)} bpm")
    c2.metric("Activity", f"{data.get('activityLevel', 0)} %")
    c3.metric("Body Temp", f"{data.get('bodyTemp', 0)} °C")
    c4.metric("Sound", f"{data.get('soundLevel', 0)} dB")
    
    st.markdown("---")
    
    g1, g2 = st.columns(2)
    with g1:
        st.caption("Heart Rate")
        st.components.v1.iframe(f"{GRAFANA_PUBLIC_URL}/d-solo/{DASHBOARD_UID}/smart-shelter-monitor?orgId=1&var-animal_id={aid}&panelId={ANIMAL_PANELS['Heart Rate']}&refresh=5s&theme=light", height=300)
        st.caption("Body Temp")
        st.components.v1.iframe(f"{GRAFANA_PUBLIC_URL}/d-solo/{DASHBOARD_UID}/smart-shelter-monitor?orgId=1&var-animal_id={aid}&panelId={ANIMAL_PANELS['Body Temp']}&refresh=5s&theme=light", height=300)
    with g2:
        st.caption("Activity")
        st.components.v1.iframe(f"{GRAFANA_PUBLIC_URL}/d-solo/{DASHBOARD_UID}/smart-shelter-monitor?orgId=1&var-animal_id={aid}&panelId={ANIMAL_PANELS['Activity']}&refresh=5s&theme=light", height=300)
        st.caption("Sound")
        st.components.v1.iframe(f"{GRAFANA_PUBLIC_URL}/d-solo/{DASHBOARD_UID}/smart-shelter-monitor?orgId=1&var-animal_id={aid}&panelId={ANIMAL_PANELS['Sound']}&refresh=5s&theme=light", height=300)

render_header()
if st.session_state.view == 'home': render_home()
elif st.session_state.view == 'room': render_room()
elif st.session_state.view == 'animal': render_animal()