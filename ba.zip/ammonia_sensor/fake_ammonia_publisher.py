import os
import json
import time
import random
import paho.mqtt.client as mqtt

MQTT_HOST = os.getenv("MQTT_HOST", "150.140.186.118")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
TOPIC = os.getenv("AMMONIA_TOPIC", "smart_shelter/room/ammonia")
PERIOD = int(os.getenv("PERIOD_SEC", "10"))

def clamp(x, lo, hi):
    return max(lo, min(hi, x))

def gen_ammonia_ppm():
    # baseline 2..15
    base = clamp(random.gauss(8, 3), 1.0, 18.0)
    # occasional spike
    if random.random() < 0.08:
        base = clamp(base + random.uniform(10, 20), 5.0, 35.0)
    return round(base, 2)

def main():
    client = mqtt.Client()
    client.connect(MQTT_HOST, MQTT_PORT, 60)

    while True:
        nh3 = gen_ammonia_ppm()
        payload = {"ammonia_ppm": nh3, "ts": time.time()}
        client.publish(TOPIC, json.dumps(payload), qos=0, retain=False)
        print(f"Published NH3={nh3} ppm to '{TOPIC}'")
        time.sleep(PERIOD)

if __name__ == "__main__":
    main()
