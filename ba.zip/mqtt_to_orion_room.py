import os
import json
import requests
import time
import paho.mqtt.client as mqtt

ORION = os.getenv("ORION_URL", "http://orion:1026")
FIWARE_SERVICE = os.getenv("FIWARE_SERVICE", "smart_shelter")
FIWARE_SERVICEPATH = os.getenv("FIWARE_SERVICEPATH", "/")
MQTT_HOST = os.getenv("MQTT_HOST", "150.140.186.118")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
ROOM_ID = os.getenv("ROOM_ID", "Room:1")
REAL_ROOM_TOPIC = os.getenv("REAL_ROOM_TOPIC", "json/Room monitoring/mclimate-co2-sensor:1")
AMMONIA_TOPIC = os.getenv("AMMONIA_TOPIC", "smart_shelter/room/ammonia")

RECEIVER_URL = "http://receiver:5050/notify"

def headers():
    return {
        "Content-Type": "application/json",
        "Fiware-Service": FIWARE_SERVICE,
        "Fiware-ServicePath": FIWARE_SERVICEPATH,
    }

def setup_subscription():
    time.sleep(5)
    print("[Room] Checking for existing subscriptions...")
    try:
        # 1. DELETE old subscriptions
        resp = requests.get(f"{ORION}/v2/subscriptions", headers=headers())
        if resp.status_code == 200:
            for sub in resp.json():
                if (sub.get("subject", {}).get("entities", [{}])[0].get("type") == "Room"):
                    sub_id = sub["id"]
                    print(f"[Room] Deleting old subscription: {sub_id}")
                    requests.delete(f"{ORION}/v2/subscriptions/{sub_id}", headers=headers())

        # 2. CREATE fresh subscription
        payload = {
            "description": "Notify Receiver to store Room history",
            "subject": {
                "entities": [{"idPattern": ".*", "type": "Room"}],
                "condition": {"attrs": []}
            },
            "notification": {
                "http": {"url": RECEIVER_URL},
                "attrsFormat": "normalized"
            },
            "throttling": 1
        }
        r = requests.post(f"{ORION}/v2/subscriptions", headers=headers(), json=payload)
        print(f"[Room] Subscription created: {r.status_code}")
    except Exception as e:
        print(f"[Room] Sub Error: {e}")

def ensure_room():
    payload = {
        "id": ROOM_ID, "type": "Room",
        "co2": {"type": "Number", "value": 0},
        "temperature": {"type": "Number", "value": 0},
        "humidity": {"type": "Number", "value": 0},
        "ammonia": {"type": "Number", "value": 0},
    }
    requests.post(f"{ORION}/v2/entities", headers=headers(), json=payload)

def patch_attrs(attrs):
    url = f"{ORION}/v2/entities/{ROOM_ID}/attrs"
    r = requests.patch(url, headers=headers(), json=attrs)
    if r.status_code == 404:
        ensure_room()
        requests.patch(url, headers=headers(), json=attrs)

def on_message(client, userdata, msg):
    try:
        attrs = {}
        if msg.topic == REAL_ROOM_TOPIC:
            data = json.loads(msg.payload.decode()).get("object", {})
            if "CO2" in data:
                attrs["co2"] = {"type": "Number", "value": float(data["CO2"])}
                attrs["temperature"] = {"type": "Number", "value": float(data["sensorTemperature"])}
                attrs["humidity"] = {"type": "Number", "value": float(data["relativeHumidity"])}
                print(f"[Room] Updated Real Sensors")

        elif msg.topic == AMMONIA_TOPIC:
            data = json.loads(msg.payload.decode())
            attrs["ammonia"] = {"type": "Number", "value": float(data["ammonia_ppm"])}
            print(f"[Room] Updated Ammonia")

        if attrs:
            patch_attrs(attrs)

    except Exception as e:
        print(f"[Room] Error: {e}")

def main():
    setup_subscription()
    ensure_room()
    c = mqtt.Client()
    c.on_message = on_message
    c.connect(MQTT_HOST, MQTT_PORT, 60)
    c.subscribe([(REAL_ROOM_TOPIC, 0), (AMMONIA_TOPIC, 0)])
    print(f"[Room] Bridge started")
    c.loop_forever()

if __name__ == "__main__":
    main()