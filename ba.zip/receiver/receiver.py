import os
from datetime import datetime, timezone
from flask import Flask, request, jsonify
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS # <--- Import this

FIWARE_SERVICE = os.getenv("FIWARE_SERVICE", "smart_shelter")
FIWARE_SERVICEPATH = os.getenv("FIWARE_SERVICEPATH", "/")

INFLUX_URL = os.getenv("INFLUX_URL", "http://influxdb:8086")
INFLUX_TOKEN = os.getenv("INFLUX_TOKEN", "super-secret-token")
INFLUX_ORG = os.getenv("INFLUX_ORG", "smart_shelter")
INFLUX_BUCKET = os.getenv("INFLUX_BUCKET", "vitals")

client = InfluxDBClient(url=INFLUX_URL, token=INFLUX_TOKEN, org=INFLUX_ORG)
# Use SYNCHRONOUS write to ensure data is saved immediately
write_api = client.write_api(write_options=SYNCHRONOUS) 

app = Flask(__name__)

def now_utc():
    return datetime.now(timezone.utc)

def ngsi_value(attr):
    if isinstance(attr, dict):
        return attr.get("value")
    return None

@app.post("/notify")
def notify():
    data = request.get_json(silent=True) or {}
    entities = data.get("data", [])

    points = []
    for ent in entities:
        ent_id = ent.get("id", "")
        ent_type = ent.get("type", "")

        if ent_type == "Room":
            room_id = ent_id
            co2 = ngsi_value(ent.get("co2"))
            hum = ngsi_value(ent.get("humidity"))
            temp = ngsi_value(ent.get("temperature"))
            ammonia = ngsi_value(ent.get("ammonia"))

            p = Point("room_env").tag("roomId", room_id).time(now_utc(), WritePrecision.NS)
            if co2 is not None: p = p.field("co2", float(co2))
            if hum is not None: p = p.field("humidity", float(hum))
            if temp is not None: p = p.field("temperature", float(temp))
            if ammonia is not None: p = p.field("ammonia", float(ammonia))
            points.append(p)

        if ent_type == "Animal":
            animal_id = ent_id
            room_id = ngsi_value(ent.get("roomId")) or "Room:1"
            heart = ngsi_value(ent.get("heartRate"))
            activity = ngsi_value(ent.get("activityLevel"))
            body_temp = ngsi_value(ent.get("bodyTemp"))
            sound = ngsi_value(ent.get("soundLevel"))

            p = (Point("animal_vitals")
                .tag("animalId", animal_id)
                .tag("roomId", str(room_id))
                .time(now_utc(), WritePrecision.NS))
            
            if heart is not None: p = p.field("heartRate", float(heart))
            if activity is not None: p = p.field("activityLevel", float(activity))
            if body_temp is not None: p = p.field("bodyTemp", float(body_temp))
            if sound is not None: p = p.field("soundLevel", float(sound))
            points.append(p)

    if points:
        write_api.write(bucket=INFLUX_BUCKET, record=points)

    return jsonify({"status": "ok"}), 200

@app.get("/health")
def health():
    return "ok", 200

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5050)