import os
import json
import requests
import time
import paho.mqtt.client as mqtt

# Configuration
ORION = os.getenv("ORION_URL", "http://orion:1026")
FIWARE_SERVICE = os.getenv("FIWARE_SERVICE", "smart_shelter")
FIWARE_SERVICEPATH = os.getenv("FIWARE_SERVICEPATH", "/")
MQTT_HOST = os.getenv("MQTT_HOST", "150.140.186.118")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
TOPIC = os.getenv("ANIMALS_TOPIC", "smart_shelter/animals")
ROOM_ID = os.getenv("ROOM_ID", "Room:1")

RECEIVER_URL = "http://receiver:5050/notify"

# Create a Session to reuse TCP connections (Critical for performance)
session = requests.Session()
session.headers.update({
    "Content-Type": "application/json",
    "Fiware-Service": FIWARE_SERVICE,
    "Fiware-ServicePath": FIWARE_SERVICEPATH,
})

def setup_subscription():
    """Resets subscription with NO throttling to ensure all data is captured."""
    time.sleep(5)
    print("[Animals] Checking subscriptions...")
    try:
        # 1. DELETE old subscriptions
        resp = session.get(f"{ORION}/v2/subscriptions")
        if resp.status_code == 200:
            for sub in resp.json():
                if (sub.get("subject", {}).get("entities", [{}])[0].get("type") == "Animal"):
                    sid = sub["id"]
                    session.delete(f"{ORION}/v2/subscriptions/{sid}")
                    print(f"[Animals] Deleted old sub: {sid}")

        # 2. CREATE fresh subscription (No Throttling)
        payload = {
            "description": "Notify Receiver to store Animal history",
            "subject": {
                "entities": [{"idPattern": ".*", "type": "Animal"}],
                "condition": {"attrs": []}
            },
            "notification": {
                "http": {"url": RECEIVER_URL},
                "attrsFormat": "normalized"
            }
            # removed "throttling": 1 to prevent data loss during bursts
        }
        r = session.post(f"{ORION}/v2/subscriptions", json=payload)
        print(f"[Animals] Subscription created: {r.status_code}")
    except Exception as e:
        print(f"[Animals] Sub Error: {e}")

def ensure_animal(animal_id):
    """Creates the animal entity if it doesn't exist."""
    payload = {
        "id": animal_id, "type": "Animal",
        "roomId": {"type": "Text", "value": ROOM_ID},
        "heartRate": {"type": "Number", "value": 0},
        "activityLevel": {"type": "Number", "value": 0},
        "bodyTemp": {"type": "Number", "value": 0},
        "soundLevel": {"type": "Number", "value": 0},
    }
    session.post(f"{ORION}/v2/entities", json=payload)

def on_message(client, userdata, msg):
    try:
        p = json.loads(msg.payload.decode("utf-8"))
        aid = p["animalId"]
        
        attrs = {
            "roomId": {"type": "Text", "value": ROOM_ID},
            "heartRate": {"type": "Number", "value": p["heartRate"]},
            "activityLevel": {"type": "Number", "value": p["activityLevel"]},
            "bodyTemp": {"type": "Number", "value": p["bodyTemp"]},
            "soundLevel": {"type": "Number", "value": p["soundLevel"]},
        }
        
        # Use the open session to PATCH
        url = f"{ORION}/v2/entities/{aid}/attrs"
        r = session.patch(url, json=attrs)
        
        # If not found, create and retry
        if r.status_code == 404:
            print(f"[Animals] Entity {aid} not found, creating...")
            ensure_animal(aid)
            session.patch(url, json=attrs)
        elif r.status_code not in [204, 200]:
            print(f"[Animals] Error updating {aid}: {r.status_code}")
            
    except Exception as e:
        print(f"[Animals] Msg Error: {e}")

def main():
    setup_subscription() 
    c = mqtt.Client()
    c.on_message = on_message
    c.connect(MQTT_HOST, MQTT_PORT, 60)
    c.subscribe(TOPIC, 0)
    print(f"[Animals] Bridge optimized & started on {TOPIC}")
    c.loop_forever()

if __name__ == "__main__":
    main()