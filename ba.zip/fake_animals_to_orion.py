import os
import json
import time
import random
import paho.mqtt.client as mqtt

MQTT_HOST = os.getenv("MQTT_HOST", "150.140.186.118")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
TOPIC = os.getenv("ANIMALS_TOPIC", "smart_shelter/animals")

ANIMALS = int(os.getenv("ANIMALS", "20"))
PERIOD = int(os.getenv("PERIOD_SEC", "5"))

def clamp(x, lo, hi):
    return max(lo, min(hi, x))

def gen_animal(animal_id: str):
    # activity baseline 0..100 (koble)
    activity = clamp(int(random.gauss(35, 20)), 0, 100)

    # heart rate basei activity
    # resting ~70-110, active paei kai parapanw
    hr_base = 80 + (activity * 0.7)  # 80..150
    hr = clamp(int(random.gauss(hr_base, 8)), 55, 180)

    # body temp (dogs/cats typical 37.5-39.5, gia alerts to kanoyme kai pio panw)
    bt = clamp(round(random.gauss(38.7, 0.35), 2), 37.5, 40.2)

    # sound level: mostly low-medium, occasional spikes gia ta alerts plai (nigga easter egg)
    sound = clamp(int(random.gauss(45, 12)), 30, 90)
    if random.random() < 0.06:  # 6% spike
        sound = clamp(sound + random.randint(15, 35), 30, 110)

    return {
        "animalId": animal_id,
        "heartRate": hr,
        "activityLevel": activity,
        "bodyTemp": bt,
        "soundLevel": sound,
        "ts": time.time()
    }

def main():
    client = mqtt.Client()
    client.connect(MQTT_HOST, MQTT_PORT, 60)

    animal_ids = [f"Animal:{i+1}" for i in range(ANIMALS)]

    while True:
        for aid in animal_ids:
            payload = gen_animal(aid)
            client.publish(TOPIC, json.dumps(payload), qos=0, retain=False)
        print(f"Published {ANIMALS} animals to MQTT topic '{TOPIC}'")
        time.sleep(PERIOD)

if __name__ == "__main__":
    main()
